import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


/**
 * Write a description of class GraphWorld here.
 * 
 * @author Jeff Franklin 
 * @version (a version number or a date)
 */
public class GraphWorld extends KinectWorld
{
    private static final int THUMBNAIL_WIDTH = 80;
    private static final int THUMBNAIL_HEIGHT = 60;
    public String[] sounds = {"2c", "2d", "2e", "2f", "2g", "2a", "2b", "3c", "3d", "3e", "3f", "3g", "3a", "3b"};

    public GraphWorld()
    {    
        super(THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT, 1.0, false);
        
        final int width = getWidth();
        final int height = getHeight();
        
        //addObject(new blueButton("2c.wav"),width/2,height/3); Can add a unique soundFile to each button if desired
        populateButtons();
        addObject(new Thumbnail(), width - THUMBNAIL_WIDTH/2, height - THUMBNAIL_HEIGHT/2);
        
        
    }
    
     public void populateButtons()
    {
        //White keys.
        int i = 0;
        while (i < 7)
        {
            blueButton button = new blueButton( sounds[i] + ".wav");
            addObject(button, 50 + (i*63), 85);
            i = i + 1;
        }
    }
    
    public void act()
    {
        super.act();
        if (!isConnected())
            return;
        
        UserData[] us = getTrackedUsers();
        getBackground().setColor(java.awt.Color.WHITE);
        getBackground().fill();
       //setBackground("crumpled-paper.jpg");
      
       boolean anyLeftHandUp = false;
        
        for (UserData u: us)
        {
            //Draws their stick figure:
            u.drawStickFigure(getBackground(), 60);
            //u.scaledCopy(0.75f);      //For making the skeleton fit the screen better?
            anyLeftHandUp = anyLeftHandUp || (u.getJoint(Joint.LEFT_HAND).getY() < u.getJoint(Joint.HEAD).getY());
        }
        
    }
}
