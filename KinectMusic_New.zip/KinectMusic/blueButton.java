import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * blueButton is a musical hit area for your right hand when using the Kinect.
 * 
 * @author Jeff Franklin 
 * @version 12/3/12
 */
public class blueButton extends Actor
{
    private String sound;
    private int framesNearTarget;

    
    /**
     * Create a new button with a soundFile variable
     */
    public blueButton(String soundFile)
    {
        sound = soundFile;
    }
    
    /**
     * Button Kinect Interaction
     */
    public void act() 
    {
        mousePlay();
        proxPlay();
    }
        
    /**
    * Right Hand Proximity Clip Play
    */
    public void proxPlay()
    {
        GraphWorld world = (GraphWorld)getWorld();
        UserData[] users = world.getTrackedUsers();
        for (UserData user : users)
        {
            Joint rightHand = user.getJoint(Joint.RIGHT_HAND);
            int xdist = rightHand.getX() - this.getX();
            int ydist = rightHand.getY() - this.getY();
            int straightDist = (int)Math.sqrt(xdist*xdist+ydist*ydist);
    
        
        if (straightDist < 20) 
        {
             framesNearTarget += 1;  
                if (framesNearTarget > 10)  
                    {  
                            play(); 
                            framesNearTarget = 0;  
                    }  
        }  
                else  
                {  
                    // Their hand is not near:  
                    framesNearTarget = 0;  
                }  
         }
    }
        
    /**
     * Clicking the clip plays it
     */
    public void mousePlay()
    {
        if(Greenfoot.mousePressed(this))
        {
            play();
        }
    }
   
    /**
     * Play a sound
     */
    public void play()
    {
        Greenfoot.playSound(sound);
    
    }
}
